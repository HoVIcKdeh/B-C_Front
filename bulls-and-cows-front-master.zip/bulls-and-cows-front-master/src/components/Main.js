import React from 'react';

const Main = () => {
    return (
        <div>
            {window.location.assign("/login")}
        </div>
    );
};

export default Main;